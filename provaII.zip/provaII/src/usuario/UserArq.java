package usuario;

import JFrameUsuario.FormCadUsuario;
import entidade.Usuarios;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserArq {

    public static void main(String[] args) throws Exception {
        forms();
    }

    public static void forms() {
        FormCadUsuario formCad = new FormCadUsuario();
        formCad.setVisible(true);

    }

    public static void exemploObjeto() throws Exception {
        List<Usuarios> list = new ArrayList<>();
        Arquivo file = new Arquivo();
        file.setNome("usuario.txt");
        file.setPath("C:\\Users\\ALDA MATOS\\Desktop\\POO_2");
        Usuarios user = new Usuarios();
        user.setCpf("059.858.257-25");
        user.setNome("CLODOALDO MATOS");
        user.setData(new Date());
        list.add(user);
        file.salvarObjeto(list);
        file.lerObjeto();
    }

    public static void exemploTexto() throws Exception {
        // TODO code application logic here 
        String txt = "Salvando meu primeiro arquivo";
        Arquivo file = new Arquivo();
        file.setNome("usuario.txt");
        file.setPath("C:\\Users\\ALDA MATOS\\Desktop\\POO_2");
        file.salvar(txt);
        String retorno = file.lerTexto();
        System.out.println(retorno);
    }
}
