/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usuarioDAO;

import java.util.List;
import entidade.Usuarios;

/**
 *
 * @author ALDA MATOS
 */
public class UsuarioDAO {
    private static UsuarioDAO iUserDAO;
    protected List<Usuarios> list;

    public UsuarioDAO() {
    }
    
    public synchronized static UsuarioDAO getInstance(String clazz) throws Exception {
        if (iUserDAO == null) {
            iUserDAO = (UsuarioDAO)Class.forName(clazz).newInstance();
        }
        return iUserDAO;
    }
    public void salvar(Usuarios user)throws Exception  {
        
    }
    public List<Usuarios> consultarTodos() throws Exception {
        return null;
    }
    
}


