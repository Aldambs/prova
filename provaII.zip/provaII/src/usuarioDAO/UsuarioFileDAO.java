/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usuarioDAO;

import java.util.ArrayList;
import java.util.List;
import entidade.Usuarios;
import usuario.Arquivo;

/**
 *
 * @author ALDA MATOS
 */
public class UsuarioFileDAO extends UsuarioDAO{
    
    private Arquivo file;
    
    public UsuarioFileDAO() {
        file = new Arquivo();
        file.setNome("usuarios.dat");
        file.setPath("./");
    }
    
    public void delete() {
        if (file.existe()) {
            file.delete();
        }
    }
    
    
    @Override
    public void salvar(Usuarios user) throws Exception {
        if (list == null) {
            list = new ArrayList<Usuarios>();
        }
        list.add(user);
        delete();
        file.salvarObjeto(list);
    }

    @Override
    public List<Usuarios> consultarTodos() throws Exception {
        list = (List<Usuarios>)file.lerObjeto();
        return list;
    }    
}


