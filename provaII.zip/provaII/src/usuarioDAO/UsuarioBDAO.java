/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usuarioDAO;

import entidade.Usuarios;
import java.util.List;

/**
 *
 * @author ALDA MATOS
 */
public class UsuarioBDAO extends UsuarioDAO{
    
    @Override
    public void salvar(Usuarios user) {
    }

    @Override
    public List<Usuarios> consultarTodos() {
        return null;
    }
}
