package entidade;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Usuarios implements  Serializable{
     private String login, senha, cpf, nome;
     private Date data;
     private boolean status;

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return  
                "\nCPF = " + cpf + 
                "\nNOME = " + nome +              
                "\nDATA DE CADASTRO = " + sdf.format(data) + 
                "\nSTATUS = " + status;
    }

    public Usuarios() {
        
    }

    public Usuarios(String login, String cpf, String nome, String senha,
            Date data, boolean status) {
        this.login = login;
        this.cpf = cpf;
        this.nome = nome;
        this.senha = senha;
        this.data = data;
        this.status = status;
    
    }

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the data
     */
    public Date getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Date data) {
        this.data = data;
    }

    /**
     * @return the status
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(boolean status) {
        this.status = status;
    }
     
    
}
