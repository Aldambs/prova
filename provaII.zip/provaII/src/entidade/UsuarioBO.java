package entidade;

import usuario.ExceptionUser;
import usuarioDAO.UsuarioDAO;

/**
 *
 * @author ALDA MATOS
 */
public class UsuarioBO {
    public void cadastrar(Usuarios user) throws Exception {
        if (user.getNome() == null || user.getNome().trim().isEmpty()) {
            throw new ExceptionUser("Nome do usuário Inválido");
        }
        UsuarioDAO userDao = UsuarioDAO.getInstance("UsuarioFileDAO");
        userDao.salvar(user);
    }
}
