package JFrameUsuario;

import entidade.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import usuario.Arquivo;

public class FormCadUsuario extends javax.swing.JFrame {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    List<Usuarios>list = new ArrayList<>();
    Usuarios user = new Usuarios();
    Arquivo file = new Arquivo();
    
    public FormCadUsuario() {
        file.setNome("usuário.txt");
        file.setPath("C:\\Users\\ALDA MATOS\\Desktop\\provaII");
        initComponents();
        setSize(470, 320);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupStatus = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabelTitulo = new javax.swing.JLabel();
        jLabelCPF = new javax.swing.JLabel();
        jLabelStatus = new javax.swing.JLabel();
        jLabelNome = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jLabelData = new javax.swing.JLabel();
        jRadioButtonSim = new javax.swing.JRadioButton();
        jRadioButtonNao = new javax.swing.JRadioButton();
        jFormattedTextFieldCPF = new javax.swing.JFormattedTextField();
        jFormattedTextFieldDATA = new javax.swing.JFormattedTextField();
        jPanel2 = new javax.swing.JPanel();
        jButtonConsultar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("USUÁRIO");
        setBackground(new java.awt.Color(204, 204, 255));
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelTitulo.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelTitulo.setText("PROVA DE POO\n");
        jPanel1.add(jLabelTitulo);
        jLabelTitulo.setBounds(179, 23, 105, 17);

        jLabelCPF.setText("CPF:");
        jPanel1.add(jLabelCPF);
        jLabelCPF.setBounds(12, 78, 39, 17);

        jLabelStatus.setText("Status:");
        jPanel1.add(jLabelStatus);
        jLabelStatus.setBounds(340, 80, 50, 20);

        jLabelNome.setText("Nome:");
        jPanel1.add(jLabelNome);
        jLabelNome.setBounds(12, 132, 46, 19);

        jTextFieldNome.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(12, 157, 305, 29);

        jLabelData.setText("Data:");
        jPanel1.add(jLabelData);
        jLabelData.setBounds(179, 76, 39, 20);

        buttonGroupStatus.add(jRadioButtonSim);
        jRadioButtonSim.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jRadioButtonSim.setText("SIM");
        jPanel1.add(jRadioButtonSim);
        jRadioButtonSim.setBounds(340, 100, 47, 23);

        buttonGroupStatus.add(jRadioButtonNao);
        jRadioButtonNao.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jRadioButtonNao.setText("NÃO");
        jPanel1.add(jRadioButtonNao);
        jRadioButtonNao.setBounds(340, 130, 60, 20);

        try {
            jFormattedTextFieldCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(jFormattedTextFieldCPF);
        jFormattedTextFieldCPF.setBounds(10, 100, 150, 30);

        try {
            jFormattedTextFieldDATA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(jFormattedTextFieldDATA);
        jFormattedTextFieldDATA.setBounds(190, 100, 130, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 10, 430, 210);

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButtonConsultar.setText("Consultar");
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonConsultar);

        jButtonExcluir.setText("Excluir");
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonExcluir);

        jButton1.setText("Alterar");
        jPanel2.add(jButton1);

        jButtonSalvar.setText("Salvar");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonSalvar);

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonCancelar);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(10, 230, 430, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        file.delete();
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        
        String data = jFormattedTextFieldDATA.getText();
        user.setCpf(jFormattedTextFieldCPF.getText());
        user.setNome(jTextFieldNome.getText());
        user.setStatus(jRadioButtonSim.isSelected());   
        
        try {                     
            user.setData(sdf.parse(data));
            file.salvar(user.toString());
            String retorno = file.lerTexto();
            System.out.println(retorno);
            JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar!");
        }   
        //Limpar os dados após salva - los
        jFormattedTextFieldCPF.setText(null);
        jTextFieldNome.setText(" ");
        jFormattedTextFieldDATA.setText(null);
        buttonGroupStatus.clearSelection();
           
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
       
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormCadUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormCadUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormCadUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormCadUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormCadUsuario().setVisible(true);
            }
        });
    }
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroupStatus;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JFormattedTextField jFormattedTextFieldCPF;
    private javax.swing.JFormattedTextField jFormattedTextFieldDATA;
    private javax.swing.JLabel jLabelCPF;
    private javax.swing.JLabel jLabelData;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelStatus;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButtonNao;
    private javax.swing.JRadioButton jRadioButtonSim;
    private javax.swing.JTextField jTextFieldNome;
    // End of variables declaration//GEN-END:variables
}
